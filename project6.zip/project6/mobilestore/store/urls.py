from django.urls import path
from.views import  StoreHome 
urlpatterns = [
    path("storeh",StoreHome.as_view(),name="storehome")
    
]